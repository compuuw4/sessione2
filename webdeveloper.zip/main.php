<!-- This is the header with default background image for all pages, except the home page -->

<section class="primary-section">
    <div class="container">
        
        <h1 class="primary-heading"><?= $pageTitle ?></h1>
      </div>
    </section>