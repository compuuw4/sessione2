<?php
$pageTitle = "Message is sent!";
$pageDescription = "Full stack web developer.
Greetings! I'm Dobri Dobrev , a passionate and innovative web developer
with a knack for turning ideas into digital reality. 
Let me take you on a journey through my professional story.";
require "head.php";
require "main.php";
?>

   <div class="container">
      <img src="https://img.freepik.com/free-vector/thank-you-placard-concept-illustration_114360-13436.jpg?w=996&t=st=1711989502~exp=1711990102~hmac=579fd081fa3db7b5995554d5849c7a82707a570fe8f3a5c2aaee5621b033eeca" alt="Thank you" class="thx-img">

   </div>
   






<?php

require "footer.php";

?>